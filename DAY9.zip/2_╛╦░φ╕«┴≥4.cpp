#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main()
{
    std::vector<int> v = {1,6,3,4,5,7,3,8,9,10};
    
    // find 는 정말 generic 할까 ?
	// 주어진 구간에서 처음 나오는 3의 배수를 찾고 싶다.
	auto p = std::find(std::begin(v), std::end(v), 3); //?


	return 0;
}



















//
