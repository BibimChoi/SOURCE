class Bike
{
	int gear;
public:
	Bike(int n) : gear(n) {}
};

void foo(Bike b) {}

int main()
{

}