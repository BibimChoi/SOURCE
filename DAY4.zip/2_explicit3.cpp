﻿#include <string>
#include <vector>
#include <list>    // 더블리스트

void f1(std::string s)      {}
void f2(std::vector<int> s) {}

int main()
{
	std::string s1("hello");
	std::string s2 = "hello"; 
	f1("hello");

	std::vector<int> v1(10); 
	std::vector<int> v2 = 10;
	f2(10);
}

// "webkit github"   => 웹브라우져(크롬같은)의 엔진

// source/wtf/wtf/Scope.h


