﻿class Dialog
{
public:
	void Close() {}
	static void Close2() {}
};
void foo() {}

int main()
{
	void(*f1)() = &foo; // ok.
	void(*f2)() = &Dialog::Close; // 될까요 ?
}

