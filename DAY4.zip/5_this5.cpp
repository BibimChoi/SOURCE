﻿#include <iostream>
#include <Windows.h> // windows 용 함수들..

// win32 api 에서 스레드 함수 모양
DWORD __stdcall foo(void* arg)
{
	return 0;
}
int main()
{
	CreateThread(0, 0, &foo, "A", 0, 0); // 스레드 생성함수
				// linux : pthread_create()
}




