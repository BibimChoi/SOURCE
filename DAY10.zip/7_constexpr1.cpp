// 7_constexpr1
int main()
{
	int sz = 10;
	const int c1 = 10;
	const int c2 = sz;

	int arr1[10];
	int arr2[sz];
	int arr3[c1];
	int arr4[c2];
}