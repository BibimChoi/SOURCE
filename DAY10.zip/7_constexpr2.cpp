int main()
{
	int n = 10;

	const int c1 = 10;
	const int c2 = n;
}