int Add(int a, int b)
{
	return a + b;
}

int main()
{
	int n1 = 10, n2 = 20;

	int x1[Add(1, 2)];
	int x2[Add(n1, n2)];

	int n3 = Add(n1, n2);
}