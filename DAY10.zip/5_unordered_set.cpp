#include <iostream>
#include <unordered_set>

int main()
{

}