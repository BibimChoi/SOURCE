﻿#include <iostream>
#include <string>


template<typename T, typename U> struct PAIR
{
	T first;
	U second;

	PAIR(const T& a, const U& b) : first(a), second(b) {}
};

int main()
{
	std::string s1 = "ABC";
	std::string s2 = "EFGH";
	PAIR<std::string, std::string> p1(s1, s2);
	PAIR<std::string, std::string> p2(std::move(s1), s2);
}