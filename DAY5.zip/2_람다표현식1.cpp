﻿// 2_람다표현식1 - 127 page

int add(int a, int b) { return a + b; }

void foo(  int(*f)(int, int) )
{
}
int main()
{
	foo(add); // ok 
}