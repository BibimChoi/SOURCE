﻿#define _CRT_SECURE_NO_WARNINGS
#include <iostream>

// Rule Of 3/5 - 102page

// 생성자에서 자원을 할당하게 되면
// 

class People
{
	char* name;
	int   age;
public:
	People(const char* s, int a) : age(a)
	{
		name = new char[strlen(s) + 1];
		strcpy(name, s);
	}
	~People() { delete[] name;  }

	People(const People& p) : age(p.age)
	{
		name = new char[strlen(p.name) + 1];
		strcpy(name, p.name);
	}

	People& operator=(const People& p)
	{
		if (&p == this) return *this;

		age = p.age;

		delete[] name;
		name = new char[strlen(p.name) + 1];
		strcpy(name, p.name);

		return *this;
	}
};
int main()
{
	People p1("kim", 20);
	People p2 = p1; 
	p2 = p1; 
}




