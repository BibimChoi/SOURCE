﻿#include <iostream>
#include <vector>
#include <mutex>
#include <string>
#include <complex>

// 객체의 복사 방법   

int main()
{
	std::complex<double> c1(1, 2); 
	std::complex<double> c2 = c1;  

	std::vector<int> v1(10); 
	std::vector<int> v2 = v1;

	std::mutex m1;
	std::mutex m2 = m1; // error. 복사 생성자 삭제.
}
