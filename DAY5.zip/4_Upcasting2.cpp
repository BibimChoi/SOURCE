﻿// 6_Upcasting1.cpp      140 page ~
#include <vector>

class Animal
{
public:	int age;
};
class Dog : public Animal
{
public:	int color;
};
int main()
{
	// Upcasting 활용/장점
	std::vector<Dog*> v1;  // Dog 만 보관하는 vector

}
