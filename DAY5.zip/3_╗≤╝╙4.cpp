﻿// 139 page
class Animal 
{
public:
	Animal() {}
};
class Dog : public Animal
{
};

int main()
{
	// 다음중 에러를 모두 고르세요
	Animal a; //
	Dog    d; //
}

