﻿// 7_가상함수1  144 page ~

#include <iostream>

class Animal
{
public:
	void Cry() { std::cout << "Animal Cry" << std::endl; }
};
class Dog : public Animal
{
public:
	void Cry() { std::cout << "Dog Cry" << std::endl; }
};

int main()
{
	Animal a; a.Cry(); // 
	Dog    d; d.Cry(); // 

	Animal* p = &d;

	p->Cry();  // 1 ? 2
}
