﻿#include <iostream>
#include <vector>
#include <algorithm>

int main()
{
	std::vector<int> v = { 1,2,6,5,4,3,7,8 };

	// v에서 3을 찾고 싶다.
	auto p1 = std::find(begin(v), end(v), 3);
	std::cout << *p1 << std::endl;

	// v에서 1번째 나오는 3의 배수를 찾고 싶다.?
}

