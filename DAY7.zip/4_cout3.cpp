// 6_cout - 187(136)page
//#include <iostream>

#include <cstdio>
namespace std
{
	class ostream
	{
	public:
		ostream& operator<<(int n)
		{
			printf("%d", n);
			return *this;
		}
		ostream& operator<<(double d) { printf("%f", d); return *this; }
		ostream& operator<<(const char* s) { printf("%s", s); return *this; }

		ostream& operator<<( ostream&(*f)(ostream&) )
		{ 
			f(*this);   // endl(cout)
			return *this; 
		}
	};
	ostream cout;

	// endl�� ��ü�� �Լ� �����ϴ�.
	ostream& endl(ostream& os)
	{
		os << "\n";
		return os;
	}
}
std::ostream& tab(std::ostream& os)
{
	os << "\t";
	return os;
}
std::ostream& menu(std::ostream& os)
{
	os << "1. ���\n";
	os << "2. ���\n";
	return os;
}
int main()
{
	std::cout << menu;

	std::cout << std::hex <<  10;
	
	//std::cout.setbase(ios_base::hex);
	//cout << 10;

	std::cout << "A" << tab << "B" << std::endl;

	std::cout << std::endl; // cout.operator<<(endl)
						//  cout.operator<<(�Լ�������)



	std::endl(std::cout); // ���� ����..
						// endl�� �Լ� �Դϴ�.
}


