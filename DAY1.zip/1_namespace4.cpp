﻿// namespace alias
#include <algorithm>

namespace Test
{
	int min(int a, int b) { return b < a ? b : a; }
}

int main()
{
	int n = Test::min(1, 2);
}
