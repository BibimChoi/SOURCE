#include <iostream>
#include <string>
#include <conio.h>
using namespace std;

class Edit
{
	string data;
public:
	string getData()
	{
		cin >> data;
		return data;
	}
};

int main()
{
	Edit e;
	while (1)
	{
		cout << e.getData() << endl;
	}
}


