// ���� ������.cpp
class Base
{
private:   int a;
protected: int b;
public:    int c;
};

class Derived : public Base  
{
};

int main()
{
	Base base;
	base.a = 1; 
	base.b = 1; 
	base.c = 1; 

	Derived derived;
	derived.b = 1; 
	derived.c = 1; 			
	
}













