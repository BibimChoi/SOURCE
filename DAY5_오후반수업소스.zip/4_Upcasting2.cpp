﻿// 6_Upcasting1.cpp      140 page ~
#include <vector>

class Animal
{
public:	
	int age;
};

// 핵심
// A와 B를 하나의 vector(또는 배열)에 
// 넣어서 관리하고 싶다.

// => A와 B의 공통의 기반 클래스를 설계해라


class Dog : public Animal
{
public:	
	int color;
};
class Cat : public Animal
{
public:
	int speed;
};










int main()
{
	// Upcasting 활용/장점
	std::vector<Dog*> v1;    // Dog 만 보관하는 vector
	std::vector<Animal*> v2; // Animal 과 모든 파생 클래스의 객체를 보관할수 있다.
							 // 동종(동일 기반 클래스를 사용하는 타입)을 보관할수 있다.

}



