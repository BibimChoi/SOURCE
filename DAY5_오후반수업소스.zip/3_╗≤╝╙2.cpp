﻿// 5_상속2

class Base
{
private:	int a;	// 자신의 멤버 함수만 접근 가능
protected:	int b;	// 자신의 멤버와 파생클래스의 멤버에서 접근 가능.
public:		int c;	// 모든 곳에서 접근 가능
};
class Derived : public Base  
{
public:
	void foo()
	{
		a = 0;	// error
		b = 0;  // ok
		c = 0;  // ok
	}
};
int main()
{
	Base base;
	base.a = 0; // error
	base.b = 0; // error
	base.c = 0; // ok
}
