﻿#include <iostream>
#include <vector>
#include <mutex>
#include <string>
#include <complex>

// 객체의 복사 방법   

int main()
{
	std::complex<double> c1(1, 2); 
	std::complex<double> c2 = c1;  // 얕은복사, 디폴트 복사 생성자 사용

	std::vector<int> v1(10); 
	std::vector<int> v2 = v1; // 깊은 복사로 구현

	std::mutex m1;
	std::mutex m2 = m1; // error. 복사 생성자 삭제.
				// mutex 클래스 제작자는 
				// 복사 생성자를 "삭제" 했습니다.
}

// C++ 표준 라이브러리인 STL 의 각 클래스는
// 다양한 복사 전략으로 만들어져 있습니다.