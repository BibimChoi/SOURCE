﻿// 객체복사4.  1번 복사해오세요.

#define _CRT_SECURE_NO_WARNINGS 


#include <iostream>



class People
{
	char* name;
	int   age;
public:
	People(const char* n, int a) : age(a)
	{
		name = new char[strlen(n) + 1];
		strcpy(name, n);
	}
	~People() { delete[] name; }

	// 컴파일러에게 복사생성자를 만들지 못하게 한다.
	People(const People&) = delete; // C++11의 함수 삭제라는 기술
								    // 컴파일러에게 특정 함수를 만들지 못하게 할때 사용
};

int main()
{
	People p1("kim", 20);
	People p2 = p1;  // 컴파일 에러
					// 복사생성자가 없으므로 "삭제된 함수를 사용하려고 합니다." 라고 에러
					// "싱글톤" 같은 디자인 기법에서 널리 사용
				
}


