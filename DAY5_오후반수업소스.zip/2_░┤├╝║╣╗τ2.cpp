﻿#define _CRT_SECURE_NO_WARNINGS   

#include <iostream>


class People
{
	char* name;
	int   age;
public:
	People(const char* n, int a) : age(a)
	{
		name = new char[strlen(n) + 1];
		strcpy(name, n);
	}
	~People() { delete[] name; }


	// 해결책 1. 깊은 복사로 구현한 복사 생성자
	People(const People& p) 
		: age(p.age) // 포인터가 아닌 멤버는 그냥 복사
	{
		// 포인터는 주소를 복사하지 말고 메모리 자체를 복사
		name = new char[strlen(p.name) + 1];

		strcpy(name, p.name);

	}
};

int main()
{
	// 깊은 복사일때 아래 코드의 메모리를 생각해 보세요
	People p1("kim", 20);
	People p2 = p1;     
	People p3 = p1;
	People p4 = p1;
}












