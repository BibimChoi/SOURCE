﻿#define _CRT_SECURE_NO_WARNINGS   // 보안관련 에러내지 말라는것

// 1_객체복사.cpp   102 page ~
#include <iostream>

// 1. 클래스 안에 포인터 멤버가 없으면
//    "디폴트 복사 생성자를 사용해도 나쁘지 않습니다."

// 2. 클래스 안에 포인터 멤버가 있으면
//   "디폴트 복사 생성자는 "얕은복사(shallow copy)" 현상이 
//   있습니다.

// 3. 사용자가 복사 생성자를 만들어서 해결해야 합니다.
//    A. 깊은 복사
//    B. 참조 계수
//    C. 복사 금지
//    D. STL 사용



class People
{
	char* name;
	int   age;
public:
	People(const char* n, int a) : age(a)
	{
		name = new char[strlen(n) + 1];
		strcpy(name, n);
	}
	~People() { delete[] name; }
};

int main()
{
	People p1("kim", 20);
	People p2 = p1;     // runtime error
						// 복사 생성자 호출
						// 컴파일러가 제공하는 버전 사용
}


