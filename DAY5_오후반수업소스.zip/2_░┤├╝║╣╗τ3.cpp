﻿#define _CRT_SECURE_NO_WARNINGS  

#include <iostream>

class People
{
	char* name;
	int*  ref; // 참조계수를 가리킬 포인터

//	static int ref; // static을 사용한 참조계수 관리
					// 모든 People 객체가 공유
	int   age;
public:
	People(const char* n, int a) : age(a)
	{
		name = new char[strlen(n) + 1];
		strcpy(name, n);

		ref = new int;
		*ref = 1;
	}
	~People() 
	{
		if (--(*ref) == 0)
		{
			delete[] name;  // 자원삭제
			delete ref;     // 참조계수를 위한 메모리 삭제
		}
	}
	
	// 해결책 2. 참조계수 방식으로 구현한 복사 생성자
	People(const People& p)
		: name(p.name), ref(p.ref), age(p.age)
	{
		++(*ref);
	}
};

int main()
{
	People p1("kim", 20);
	People p2 = p1;     

	People p3("lee", 20);
	People p4 = p3;
}


