﻿// 상속과 생성자.   135page ~
#include <iostream>

// 핵심 1. 상속에서의 생성자/소멸자 호출순서
//			기반클래스 생성자, 파생 클래스 생성자
// 2. 기반 클래스 생성자는 인자 없는 생성자 호출

// 3. 기반 클래스의 다른 생성자를 호출하려면 파생클래스의 초기화 리스트에서 명시적으로 호출

// 4. 정확한 원리만 알면 됩니다.

class Base
{
public:
	Base()      { std::cout << "Base()"  << std::endl; }
	Base(int a) { std::cout << "Base(int)" << std::endl; }
	~Base()     { std::cout << "~Base()" << std::endl; }
};
/*
class Derived : public Base
{
public:
	Derived()                { std::cout << "Derived()" << std::endl; } 
	Derived(int a) : Base(a) { std::cout << "Derived(int)" << std::endl; }
	~Derived()               { std::cout << "~Derived()" << std::endl; }
};
*/

// 정확한 원리는 아래와 같습니다
class Derived : public Base
{
public:
	// 사용자가 만든 코드
//	Derived()      { std::cout << "Derived()" << std::endl; }
//	Derived(int a) { std::cout << "Derived(int)" << std::endl; }
//	~Derived()     { std::cout << "~Derived()" << std::endl; }

	// 컴파일러가 변경한 코드
	Derived()      : Base() { std::cout << "Derived()" << std::endl; }
	Derived(int a) : Base() { std::cout << "Derived(int)" << std::endl; }
	~Derived()              { std::cout << "~Derived()" << std::endl; ~Base(); }
};

int main()
{
//	Derived d;	
	Derived d(5);
}

