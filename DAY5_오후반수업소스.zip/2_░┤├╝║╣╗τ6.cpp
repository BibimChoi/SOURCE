﻿#define _CRT_SECURE_NO_WARNINGS  

#include <iostream>

// 1. 클래스 안에 포인터 멤버가 없으면 ==> 디폴트 복사 생성자를 사용해도 문제 없다.

// 2. 클래스 안에 포인터 멤버가 있으면 ==> 얕은 복사를 해결해야 한다

// 최선의 코드 
// 포인터를 사용하지 말고 STL 을 사용하자.!!

// char* => string
// int*  => vector<int>  또는 스마트포인터

#include <string>

class People
{
	std::string name;
	int   age;
public:
	People(std::string n, int a) : name(n), age(a)
	{
	}
};

int main()
{
	People p1("kim", 20);
	People p2 = p1;     
}


