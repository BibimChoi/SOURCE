﻿// 5_상속1.cpp   132page ~
#include <iostream>
#include <string>


// 각 클래스의 공통의 특징을 뽑아서
// 새로운 클래스로 설계
class People		// 기반(Base) 클래스, Super 클래스, 부모(parent) 클래스
{
	std::string name;
	int    age;
};
// "단축표기의 미학"
// 상속(inheritance)
// C++   : class Student : public People
// C#    : class Student : People
// java  : class Student extends People
// python: class Student(People):
class Student : public People	// 파생(Derived) 클래스, Sub 클래스, 자식(Child) 클래스
{
	int    id;
};

class Professor : public People
{
	int    major;
};
int main()
{
	Student s;
	Professor p;

}

// 2:55분 부터 진행하겠습니다.