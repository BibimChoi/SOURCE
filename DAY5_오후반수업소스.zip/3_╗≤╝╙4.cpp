﻿// protected 생성자의 설계 철학 : 자신의 객체는 만들수 없지만(추상적 존재)
//								파생 클래스의 객체는 만들수 있게하는 것(구체적(concrete) 존재)

// 139 page
class Animal 
{
//public:  1, 2 모두 에러 아님
//private: 1, 2 모두 에러

protected: // 1번만 에러, 2번은 ok
	Animal() {}
};
class Dog : public Animal
{
public:
	Dog() : Animal() {}
};

int main()
{
	// 다음중 에러를 모두 고르세요
	Animal a; // 1. error
	Dog    d; // 2. ok
}

