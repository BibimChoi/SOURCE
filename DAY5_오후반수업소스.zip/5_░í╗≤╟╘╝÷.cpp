﻿// 7_가상함수1  144 page ~

#include <iostream>

class Animal
{
public:
	        void Cry()  { std::cout << "Animal Cry"  << std::endl; }	// 1
	virtual void Cry2() { std::cout << "Animal Cry2" << std::endl; }	// 1
};
class Dog : public Animal
{
public:
	// 함수 오버라이드(override) : 기반 클래스의 함수를 파생클래스가 다시 만드는 것
	        void Cry()  { std::cout << "Dog Cry" << std::endl; }	// 2
	        void Cry2() { std::cout << "Dog Cry2" << std::endl; }	// 2
};

int main()
{
	Animal a;  // a.Cry(); // 1
	Dog    d;  // d.Cry(); // 2

	Animal* p = &d;

//	if (사용자입력 == 1) p = &a;

	// 컴파일러는 아래 코드를 컴파일 할때
	// p가 어떤 객체를 가리키는지 알수 있을까요 ?

	// 아래 코드가 컴파일 되는 원리
	// 1. p의 타입을 조사한후, Cry(), Cry2()함수의 선언을 보고 "virtual"이 있는지 확인
	// 2. 없으면 static binding,  있으면 dynamic binding
	p->Cry();  
	p->Cry2(); 
}



// 함수 바인딩( binding )
// p->Cry() 를 어느 함수와 연결할것인가 ?

// 1. static binding : 컴파일러가 컴파일 시간에 어느함수를 호출할지를 결정.
//					   컴파일 시간에는 p가 어떤 객체를 가리키는지 알수 없다.
//					   그래서 p의 포인터 타입으로만 함수 결정
//						Animal Cry 호출
// 빠르다. 논리적이지 않다.
// C++, C#


// 2. dynamic binding : 컴파일 시간에 p가 가리키는 곳의 메모리를 조사하는 기계어 코드 생성
//					 실행시간에 p가 가리키는 메모리 조사후에 함수 결정
//					 p가 Dog를 가리키면 Dog Cry 호출
// 느리다. 논리적이다
// java, python, swift, kotlin 
// C++과 C#의 "virtual" 함수

