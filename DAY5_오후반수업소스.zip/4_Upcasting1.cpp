﻿// 6_Upcasting1.cpp      140 page ~
#include <vector>

class Animal
{
public:	int age;
};

class Dog : public Animal
{
public:	int color;
};

int main()
{
	Dog     dog;

	Dog*    p1 = &dog; // ok
	int*    p2 = &dog; // error
	Animal* p3 = &dog; // ok

	// 기반 클래스 타입의 포인터로 파생 클래스 주소를 담을수 있다 - upcasting

	// 주의 사항
	p3->age   = 10; // ok
	p3->color = 10; // error
	// 기반 클래스 타입 포인터로는 "기반 클래스 멤버만 접근가능, 파생클래스 멤버 접근 안됨"
	// 컴파일 시에 "포인터 타입만으로 에러 체크를 하기 때문에"

	// p3의 타입을 캐스팅 하면 접근가능
	(static_cast<Dog*>(p3))->color = 10;
}

// 질문 1. 2개의 기반 클래스 가능한가요 ? - YES,, 다중상속.. 다음주에
class Derived : public A, public B
{
};

Derived d;
A* pA = &d;
B* pB = &d;





