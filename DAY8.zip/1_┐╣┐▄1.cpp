int foo()
{
	if (����)
		return -1;

	return 0;
}

int main()
{
	int ret = foo();
	//..
}