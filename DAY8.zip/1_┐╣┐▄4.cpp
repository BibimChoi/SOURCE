// noexcept
#include <iostream>

void foo()
{
	//....	
}

int main()
{
	foo();
}