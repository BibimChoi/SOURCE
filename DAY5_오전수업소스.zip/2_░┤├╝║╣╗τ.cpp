﻿
// 1_객체복사.cpp   102 page ~
#define _CRT_SECURE_NO_WARNINGS
#include <iostream>

// 클래스 안에 "포인터 멤버가 있고, 동적메모리 할당을 하면"
// 컴파일러가 제공하는 디폴트 복사 생성자는

// 메모리 자체를 복사 하지 않고
// 주소만 복사하는 "얕은 복사(Shallow Copy) 문제가 있습니다.

// 반드시 사용자가 복사 생성자를 제공해서 해결해야 합니다

// 해결책 1. 깊은 복사
//        2. 참조 계수
//        3. 복사 금지 


class People
{
	char* name;     
	int   age;    
public:
	People(const char* n, int a) : age(a)
	{
		name = new char[strlen(n) + 1];
		strcpy(name, n);
	}
	~People() { delete[] name; }
};
   
int main()
{
	People p1("kim", 20);
	People p2 = p1;      // People p2(p1) 의 모양이므로 복사 생성자 호출
						// 사용자가 만들지 않으면 컴파일러가 제공
						// ==> 모든 멤버를 그냥 복사..
}



