﻿// protected 생성자를 사용하는 이유 : 자신은 만들수 없지만(추상적 존재)
//									파생 클래스는 만들수 있게 하겠다(구체적(concrete) 존재)

// 139 page
class Animal 
{
protected:
	Animal() {}
};
class Dog : public Animal
{
public:
	Dog() : Animal() {}
};

int main()
{
	// 다음중 에러를 모두 고르세요
	Animal a; // error. protected는 외부에서는 접근 안되므로!!
	Dog    d; // ok..   Dog() 생성자 안에서는 기반 클래스의 protected에 접근할수 있으므로
				
}

