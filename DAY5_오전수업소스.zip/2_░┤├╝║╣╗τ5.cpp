﻿#include <iostream>
#include <vector>
#include <mutex>
#include <string>
#include <complex>

// 핵심 정리
// 1. 복사 생성자 개념 :  자신과 동일한 타입의 객체로 초기화 될때 사용
//    Point pt2 = pt1; // 이때 호출

// 2. 사용자가 만들지 않으면 컴파일러가 제공 - 모든 멤버를 얕은 복사

// 컴파일러가 제공하는 복사 생성자
// (A). 포인터 멤버가 없으면 그냥 사용하면 된다.

// (B). 포인터가 있으면 얕은 복사 현상발생 - 사용자가 복사 생성자를 만들어서 해결해야한다
//      1. 깊은복사
//      2. 참조계수
//      3. 복사금지

// 최선의 답 : 포인터 사용하지 말고, 해당 타입의 클래스 사용
//			char* => string
//          int*  => vector<int>

// 객체의 복사 방법   

int main()
{
	std::complex<double> c1(1, 2); 
	std::complex<double> c2 = c1;  // 디폴트 복사 생성자 사용(얕은복사)할 것이다!

	std::vector<int> v1(10); 
	std::vector<int> v2 = v1;  // 깊은 복사를 사용하고 있다.

	std::mutex m1;		// 스레드 동기화에 사용
	std::mutex m2 = m1; // error. 복사 생성자 삭제.
						// mutex 클래스는 내부적으로 "복사생성자를 삭제" 하고 있습니다
}


