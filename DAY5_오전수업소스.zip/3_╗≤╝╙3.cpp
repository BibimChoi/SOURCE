﻿// 상속과 생성자.   135page ~
#include <iostream>

// 객체 생성시
// 1. 기반클래스생성자 호출, 파생클래스 생성자 호출
//    파생클래스소멸자,      기반 클래스 소멸자

// 2. 기반클래스는 디폴트 버전의 생성자 호출

// 3. 기반 클래스의 다른 버전을 호출하려면 초기화 리스트에서 명시적으로 호출해야 한다.

// 4. 정확한 원리!!!

class Base
{
public:
	Base()      { std::cout << "Base()"  << std::endl; }
	Base(int a) { std::cout << "Base(int)" << std::endl; }
	~Base()     { std::cout << "~Base()" << std::endl; }
};
/*
class Derived : public Base
{
public:
	Derived()       { std::cout << "Derived()" << std::endl; } 
	Derived(int a)  { std::cout << "Derived(int)" << std::endl; }
	~Derived()      { std::cout << "~Derived()" << std::endl; }
};
*/
// 상속을 사용할 경우 생성자 호출의 정확한 원리
// 위 코드를 보고 컴파일러가 아래 처럼 변경합니다.
class Derived : public Base
{
public:
	// 결국 컴파일러가 아래 처럼 기반 클래스의 디폴트 생성자를 호출하는 코드를 추가한것
	Derived()      : Base() { std::cout << "Derived()" << std::endl; }
	Derived(int a) : Base() { std::cout << "Derived(int)" << std::endl; }
	~Derived()              { std::cout << "~Derived()" << std::endl; ~Base();  }
};

int main()
{
//	Derived d;	
	Derived d(5);
}




