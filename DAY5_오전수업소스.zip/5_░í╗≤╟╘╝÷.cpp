﻿// 7_가상함수1  144 page ~

#include <iostream>

class Animal
{
public:
	void Cry()          { std::cout << "Animal Cry" << std::endl; } // 1
	virtual void Cry2() { std::cout << "Animal Cry2" << std::endl; }
};

class Dog : public Animal
{
public:
	// 함수 오버라이드(override) : 기반 클래스 멤버 함수를 파생 클래스가 재정의 하는 것
	//	"오버로딩(overloading)과 는 다름"
	void Cry()          { std::cout << "Dog Cry" << std::endl; }  // 2
	virtual void Cry2() { std::cout << "Dog Cry2" << std::endl; }
};

int main()
{
	Animal a; //a.Cry(); // 1 번 호출
	Dog    d; //d.Cry(); // 2 번 호출

	Animal* p = &d;		

//	if (사용자입력 == 1) p = &a;

	// 컴파일러는 p가 d를 가리킬지 a를 가리킬지 알수 있을까요 ?
	// p는 "변수" 이므로 실제 어떤 객체를 가리키는지는 컴파일 시간에는 알수 없다. 
	
	// 컴파일러가 알고 있는 유일한 정보는 p의 타입이 "Animal*" 라는 것 이다.
	p->Cry();  // static binding 해달라 -> 컴파일 할때 함수 호출 결정 
	p->Cry2(); // dynamic binding 해달라 -> 실행할때 함수 호출 결정 (약간 느리다.)
}


// 함수 바인딩(binding )

// p->Cry() 를 어떤 함수에 연결할것인가 ?

// 1. static binding  : 컴파일러가 컴파일 시간에 결정. 
//						"p 가 가리키는 객체타입이 아닌 p자체의 타입(Animal*)"로 함수 호출결정
//						Animal Cry() 호출
// 빠르다. early binding. 논리적이지 않다. 
// C++, C#


// 2. dynamic binding : 컴파일 시간에는 "p가 가리키는 메모리를 조사하는 기계어 코드 생성"
//				       실행할때 메모리 조사후 호출
//					   실제 객체에 따라 함수 호출
//						Dog Cry() 호출
// 느리다. late binding. 논리적이다.
// java, swift, python, kotlin
// C++과 C# 에서 "virtual" 함수를 사용하면 "dynamic binding" 해달라는 의미.



