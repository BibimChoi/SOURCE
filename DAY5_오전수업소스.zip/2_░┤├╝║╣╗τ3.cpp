﻿// 객체 복사 1번 복사해 보세요.

// 1_객체복사.cpp   102 page ~
#define _CRT_SECURE_NO_WARNINGS
#include <iostream>


class People
{
	char* name;
	int* ref;   // 자원의 참조계수를 관리할
				// 포인터 변수
	int   age;
public:
	People(const char* n, int a) : age(a)
	{
		name = new char[strlen(n) + 1];
		strcpy(name, n);

		ref = new int;
		*ref = 1;
	}
	// 참조계수 기술을 사용하는 복사 생성자
	People(const People& p)
		: name(p.name), ref(p.ref), age(p.age)
	{
		++(*ref); // 참조계수 증가!!
	}

	// 참조계수를 사용하는 소멸자
	~People() 
	{
		if (--(*ref) == 0)
		{
			delete[] name; // 자원 삭제
			delete ref;
		}
	}
};

int main()
{
	// static 멤버 변수 : 모든 객체가 공유
	// 참조계수용 메모리는 모든 객체가 공유하는것은 아닙니다

	People p1("kim", 20);
	People p2 = p1;     

	People p3("lee", 20);
	People p4 = p3;
}





