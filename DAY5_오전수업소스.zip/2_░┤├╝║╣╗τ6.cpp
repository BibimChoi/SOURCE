﻿#define _CRT_SECURE_NO_WARNINGS

#include <iostream>
#include <string>

// 해결책 4. 문자열을 동적메모리할당해서 직접 관리하지 말고
//			 C++ 표준의 string을 사용하자.

class People
{
	std::string name;
	int   age;
public:
	People(std::string n, int a) : name(n), age(a)
	{
	}
};

int main()
{
	People p1("kim", 20);
	People p2 = p1;     
}




