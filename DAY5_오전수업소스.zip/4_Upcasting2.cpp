﻿// 6_Upcasting1.cpp      140 page ~
#include <vector>

class Animal
{
public:	int age;
};
class Dog : public Animal
{
public:	int color;
};
class Cat : public Animal
{
public:	int speed;
};







int main()
{
	// Upcasting 활용/장점
	// Dog* x[10];
	std::vector<Dog*> v1;  // Dog 만 보관하는 vector

	std::vector<Animal*> v2; // 기반 클래스 포인터를 저장하는 컨테이너(배열)
							 // 동종(동일기반 클래스를 사용하는 모든 타입)을 보관한다.
							// Animal 로 부터 파생된 모든것을 보관할수 있다.

	// 핵심!!!!
	// A와 B를 묶어서 관리하고 싶다.
	// ==> A와 B의 공통의 기반 클래스를 설계해라

	// Folder는 File과 Folder를 모두 보관한다.
	// File과 Folder는 공통의 기반 클래스가 필요 하다
	

}
