﻿// 6_Upcasting1.cpp      140 page ~
#include <vector>

class Animal
{
public:	
	int age;
};
class Dog : public Animal
{
public:	
	int color;
};
int main()
{
	Dog     dog;

	Dog*    p1 = &dog; // ok
	int*    p2 = &dog; // error. 타입이 다르다.
	Animal* p3 = &dog; // ok..   p3를 따라가면 Dog 가 있지만
						// Dog 안에 결국 Animal 있다.

	// Upcasting : 기반 클래스 포인터로 파생 클래스 객체를 가리키는 것

	// 주의 사항 : 기반 클래스 포인터로 파생클래스 고유 멤버를 접근할수 없다.
	//			컴파일러는 포인터 타입으로 "에러를 체크"하기 때문에
	p3->age = 10;   // ok
	p3->color = 10; // error

	// 접근하려면 포인터 타입을 캐스팅해서 사용한다.
	(static_cast<Dog*>(p3))->color = 10;
}




