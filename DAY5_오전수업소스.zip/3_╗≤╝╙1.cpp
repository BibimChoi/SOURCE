﻿// 5_상속1.cpp   132page ~
#include <iostream>
#include <string>

// 여러 클래스에서 공통된 특징이 있다면 별도의 클래스로 설계하고 
// "상속" 문법을 사용하는것이 좋다.

class People		// 기반클래스, 슈퍼 클래스, 부모 클래스
{					// Base Class, super class, parent
	std::string name;
	int         age;
};


// C++, C# : ":" 사용
// java    : extends 사용
// class Student extends People // java
// class Student(People):       // python
// class Student : People       // C#

class Student : public People		// 파생클래스, 서브 클래스, 자식 클래스
{									// Derived class, subclass,  child class
	int    id;
};
class Professor : public People
{
	int    major;
};

int main()
{
	Student s;
	Professor p;
}
