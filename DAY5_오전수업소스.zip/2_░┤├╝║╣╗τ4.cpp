﻿// 객체복사4.    1번 복사해오세요

#define _CRT_SECURE_NO_WARNINGS

#include <iostream>

class People
{
	char* name;
	int   age;
public:
	People(const char* n, int a) : age(a)
	{
		name = new char[strlen(n) + 1];
		strcpy(name, n);
	}
	~People() { delete[] name; }

	// 해결책 3. 복사생성자 삭제
	People(const People& ) = delete; // 함수 삭제라는 문법 - C++11에서 추가된 문법
								    // 컴파일러에게 특정 함수를 만들지 말라고 지시하는것

//	People() = delete; // 디폴트 생성자같은 것도 삭제 가능.
};

int main()
{
	People p1("kim", 20);
	People p2 = p1;		// 복사 생성자를 호출하는 표기법인데..
						// 복사 생성자가 없으므로(삭제되어서) 컴파일 에러!!
						// 주로 "싱글톤" 이라는 디자인 기법에서 널리 사용
}



