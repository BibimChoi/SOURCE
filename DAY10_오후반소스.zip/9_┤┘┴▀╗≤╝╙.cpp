struct X
{
	int x = 0;
};
struct A : public X
{
	int a;
};
struct B : public X
{
	int b;
};
struct C : public A, public B
{
	int c;
};
int main()
{
	C ccc;
	int n = ccc.x;
}