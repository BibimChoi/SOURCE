#include <iostream>
#include <string>

// Modern C++(C++11/14/17) �� ���� ū Ư¡ : "move"

int main()
{
	std::string s1 = "AAA";
	std::string s2 = s1;

	std::cout << s1 << ", " << s2 << std::endl;


	std::string s3 = "AAA";
	std::string s4 = std::move(s3); // modern C++�� �ٽ�

	std::cout << s3 << ", " << s4 << std::endl;

}





