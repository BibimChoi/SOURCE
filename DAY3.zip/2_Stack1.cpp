﻿// 2_Stak1 - 60 page ~
#include <iostream>

// 스택을 만들어 봅시다.
// 버전 1. C언어

int main()
{
	push(10);
	push(20);
	std::cout << pop() << std::endl;
}
